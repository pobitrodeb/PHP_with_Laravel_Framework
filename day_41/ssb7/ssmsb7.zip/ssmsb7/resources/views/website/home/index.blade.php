@extends('website.master')

@section('title')
   | NanoTech
@endsection
@section('body')
    <div class="carousel slide" data-bs-ride="carousel" data-bs-interval="1800" id="slider">
        <ol class="carousel-indicators">
            <li data-bs-target="#slider" data-bs-slider-to="0" class="active" ></li>
            <li data-bs-target="#slider" data-bs-slider-to="1" class=""> </li>
            <li data-bs-target="#slider" data-bs-slider-to="2" class=""> </li>
        </ol>

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="{{asset('/website/img/slider-1.jpg')}}" alt="" class="w-100" style="height: 550px">
            </div>

            <div class="carousel-item active">
                <img src="{{asset('/website/img/slider-2.jpg')}}" alt="" class="w-100" style="height: 550px">
            </div>

            <div class="carousel-item active">
                <img src="{{asset('/website/img/slider-3.jpg')}}" alt="" class="w-100" style="height: 550px">
            </div>

        </div>
    </div>
    @endsection
