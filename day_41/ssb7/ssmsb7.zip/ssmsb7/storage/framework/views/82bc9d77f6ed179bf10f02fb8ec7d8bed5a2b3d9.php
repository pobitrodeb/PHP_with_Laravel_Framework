<?php $__env->startSection('title'); ?>
   | NanoTech
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="carousel slide" data-bs-ride="carousel" data-bs-interval="1800" id="slider">
        <ol class="carousel-indicators">
            <li data-bs-target="#slider" data-bs-slider-to="0" class="active" ></li>
            <li data-bs-target="#slider" data-bs-slider-to="1" class=""> </li>
            <li data-bs-target="#slider" data-bs-slider-to="2" class=""> </li>
        </ol>

        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo e(asset('/website/img/slider-1.jpg')); ?>" alt="" class="w-100" style="height: 550px">
            </div>

            <div class="carousel-item active">
                <img src="<?php echo e(asset('/website/img/slider-2.jpg')); ?>" alt="" class="w-100" style="height: 550px">
            </div>

            <div class="carousel-item active">
                <img src="<?php echo e(asset('/website/img/slider-3.jpg')); ?>" alt="" class="w-100" style="height: 550px">
            </div>

        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssmsb7\resources\views/website/home/index.blade.php ENDPATH**/ ?>