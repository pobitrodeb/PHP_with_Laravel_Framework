<?php $__env->startSection('title'); ?>
    About Us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="">
        <div class="">

            <div class="container-fluid py-4 bg-primary">
                <div class="row">
                    <div class="col">
                        <h1 class="text-white text-center">All Traning  Information </h1>
                    </div>
                </div>
            </div>

            <div class="container py-5">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card card-body mb-3 border-0">
                            <h2>Who We Are</h2>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                            </p>
                        </div>
                        <div class="card card-body mb-3 border-0">
                            <h2>What We Doing</h2>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                            </p>
                        </div>
                        <div class="card card-body mb-3 border-0">
                            <h2>Our Mission Vission </h2>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                                Lorem ipsum dolor sit amet, consectetur adi
                                pisicing elit. Beatae consectetur corporis, dolore est iusto molestias offi
                                cia recusandae suscipit tenetur unde? Dolore modi nisi obcaecati quidem! <br>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssmsb7\resources\views/website/about/index.blade.php ENDPATH**/ ?>