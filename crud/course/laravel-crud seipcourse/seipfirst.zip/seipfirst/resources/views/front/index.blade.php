@extends('master')

@section('title')
    Home
    @endsection
