<?php $__env->startSection('title'); ?>
    Manage Course
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <div class="card">
                        <div class="card-header bg-primary"><h4>Manage Your Course</h4></div>
                        <div class="card-body">
                            <h4 class="text-center"><?php echo e(Session::get('message')); ?></h4>
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Title</th>
                                    <th>Teacher Name</th>
                                    <th> Fee</th>
                                    <th>Course Duration</th>
                                    <th>Starting Time</th>
                                    <th>Starting objective</th>
                                    <th>Course Details</th>
                                    <th>Blog Image</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($course['title']); ?></td>
                                    <td><?php echo e($course['techername']); ?></td>
                                    <td><?php echo e($course['fee']); ?></td>
                                    <td><?php echo e($course['duration']); ?></td>
                                    <td><?php echo e($course['startingDate']); ?></td>
                                    <td><?php echo e($course['objective']); ?></td>
                                    <td><?php echo e($course['details']); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset($course->image)); ?>" alt="" height="50" width="100"/>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('course.edit',['id' => $course->id])); ?>" class="btn btn-warning" >Edit</a>
                                        <a href="<?php echo e(route('course.delete', ['id' =>$course->id])); ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete this file.')">Delete</a>
                                    </td>
                                </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\seipfirst\resources\views/front/course-manage.blade.php ENDPATH**/ ?>