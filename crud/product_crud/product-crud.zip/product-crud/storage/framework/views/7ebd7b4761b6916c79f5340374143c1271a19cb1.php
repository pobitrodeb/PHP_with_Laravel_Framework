<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mx-auto">
                    <div class="card">
                        <div class="card-header">All Product</div>
                        <div class="card-body">
                            <h4 class="text-center"><?php echo e(Session::get('message')); ?></h4>
                            <table class="table table-bordered table-hover">
                                <thead class="text-center">
                                <tr>
                                    <th>SL NO </th>
                                    <th>Product Name </th>
                                    <th>Product Category</th>
                                    <th>Brand</th>
                                    <th>Price</th>
                                    <th>Description </th>
                                    <th>Image </th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($product['name']); ?></td>
                                        <td><?php echo e($product['category']); ?></td>
                                        <td><?php echo e($product['brand']); ?></td>
                                        <td><?php echo e($product['price']); ?></td>
                                        <td><?php echo e($product['description']); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($product->image)); ?>" alt="" height="50" width="100">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('edit-product', ['id' => $product->id])); ?>" class="btn btn-primary btn-sm" onclick="return confirm('Are you sure to update this.')">Edit</a>
                                            <a href="<?php echo e(route('delete-product', ['id' => $product->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this.')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('maseter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\product-crud\resources\views/home/mange-product.blade.php ENDPATH**/ ?>