@extends('master');

@section('body')
    <div class="container">
        <h3> this is home page </h3>
    </div>
@endsection
