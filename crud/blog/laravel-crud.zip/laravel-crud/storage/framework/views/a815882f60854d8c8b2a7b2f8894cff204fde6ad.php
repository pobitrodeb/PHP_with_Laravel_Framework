;

<?php $__env->startSection('body'); ?>
    <div class="container">
        <h3> this is home page </h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/blog/index.blade.php ENDPATH**/ ?>