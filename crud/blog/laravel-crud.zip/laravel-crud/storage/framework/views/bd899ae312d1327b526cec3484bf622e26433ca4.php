<?php
 ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/product/new.blade.php ENDPATH**/ ?>